/** @type {import('next').NextConfig} */
const nextConfig = {
  env: {
    webURL: "http://localhost:3001",
  },
};

module.exports = nextConfig;
